package com.example.elfira;

class data_mahasiswa {
    public data_mahasiswa(String getNIM, String getNama, String getJurusan) {
    }

    public void setKey(String key) {
    }
}
